#include "final_proj.h"
#include <mpi.h>

int main(){
    return 0;
}
